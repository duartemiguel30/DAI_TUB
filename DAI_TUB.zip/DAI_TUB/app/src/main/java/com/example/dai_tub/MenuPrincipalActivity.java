package com.example.dai_tub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView; // Importe TextView
import android.widget.LinearLayout;

public class MenuPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menuprincipal);

        // Referenciar o DrawerLayout
        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);

        // Referenciar o texto do menu como TextView
        TextView menuText = findViewById(R.id.menuText);

        // Definir o listener para o texto do menu
        menuText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir ou fechar o menu lateral quando o texto do menu for clicado
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        // Referenciar outros elementos e definir listeners...

    }

    // Método para alternar o estado do menu lateral
    public void toggleDrawer(View view) {
        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            drawerLayout.openDrawer(GravityCompat.START);
        }
    }

    // Implemente outras ações de botão, se necessário...

}
